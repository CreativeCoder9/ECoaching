//Initialisation of firebase
const firebaseConfig = {
    apiKey: "AIzaSyDNGGLUfK6OoI6SyFLPqLjp4aLwEPDlw0g",
    authDomain: "uniclick-d1aa5.firebaseapp.com",
    databaseURL: "https://uniclick-d1aa5.firebaseio.com",
    projectId: "uniclick-d1aa5",
    storageBucket: "uniclick-d1aa5.appspot.com",
    messagingSenderId: "44062048491",
    appId: "1:44062048491:web:7e306542791a9fa85d3eae",
    measurementId: "G-R1ZTCZWCSK"
};

firebase.initializeApp(firebaseConfig);
// Get a reference to the storage service, which is used to create references in your storage bucket
var storage = firebase.storage();

// Create a storage reference from our storage service
var storageRef = storage.ref();

var recordingsRef = storageRef.child('Audio-recordings');




//webkitURL is deprecated but nevertheless
URL = window.URL || window.webkitURL;

var gumStream; 						//stream from getUserMedia()
var rec; 							//Recorder.js object
var input; 							//MediaStreamAudioSourceNode we'll be recording
var noOfRecords = 0;
var recording = false;

// shim for AudioContext when it's not avb.
var AudioContext = window.AudioContext || window.webkitAudioContext;
var audioContext //audio context to help us record

var options = {
    monitorGain: parseInt(0, 10),
    recordingGain: parseInt(1, 10),
    numberOfChannels: parseInt(1, 10),
    encoderSampleRate: parseInt(48000, 10),
    encoderPath: encoderPath
};


var recordButton = document.getElementById("recordButton");
var stopButton = document.getElementById("stopButton");
var pauseButton = document.getElementById("pauseButton");

//workerfile
// var workerPath = 'https://archive.org/download/ffmpeg_asm/ffmpeg_asm.js';

//system compatibility check
if (!Recorder.isRecordingSupported()) {
    alert("Recording features are not supported in your browser.");
}

//add events to those 2 buttons
recordButton.addEventListener("click", startRecording);
stopButton.addEventListener("click", stopRecording);
pauseButton.addEventListener("click", pauseRecording);

function startRecording() {
    console.log("recordButton clicked");

	/*
		Simple constraints object, for more advanced audio features see
		https://addpipe.com/blog/audio-constraints-getusermedia/
	*/

    var constraints = { audio: true, video: false }

    /*
      Disable the record button until we get a success or fail from getUserMedia()
  */

    recordButton.disabled = true;
    stopButton.disabled = false;
    pauseButton.disabled = false

	/*
    	We're using the standard promise based getUserMedia()
    	https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia
	*/

    // navigator.mediaDevices.getUserMedia(constraints).then(function (stream) {
    //     console.log("getUserMedia() success, stream created, initializing Recorder.js ...");

    // 	/*
    // 		create an audio context after getUserMedia is called
    // 		sampleRate might change after getUserMedia is called, like it does on macOS when recording through AirPods
    // 		the sampleRate defaults to the one set in your OS for your playback device
    // 	*/
    //     audioContext = new AudioContext();

    //     //update the format
    //     document.getElementById("formats").innerHTML = "Format: 1 channel pcm @ " + audioContext.sampleRate / 1000 + "kHz"

    //     /*  assign to gumStream for later use  */
    //     gumStream = stream;

    //     /* use the stream */
    //     input = audioContext.createMediaStreamSource(stream);

    // 	/*
    // 		Create the Recorder object and configure to record mono sound (1 channel)
    // 		Recording 2 channels  will double the file size
    // 	*/
    //     rec = new Recorder(input, { numChannels: 1 })

    //     //start the recording process
    //     rec.record()

    //     console.log("Recording started");

    // }).catch(function (err) {
    //     //enable the record button if getUserMedia() fails
    //     recordButton.disabled = false;
    //     stopButton.disabled = true;
    //     pauseButton.disabled = true
    // });

    rec = new Recorder(options);
    rec.start().catch(function (e) {
        screenLogger('Error encountered:', e.message);
    });
    console.log("Recording started");
    recording = true;
    // rec.onpause = function (e) {
    //     console.log('Recorder is paused');
    //     rec.pause();
    //     pauseButton.innerHTML = "Resume";
    // };

    // rec.onresume = function (e) {
    //     console.log('Recorder is resuming');
    //     rec.resume()
    //     pauseButton.innerHTML = "Pause";
    // };

}

function pauseRecording() {
    console.log("pauseButton clicked rec.recording=", rec.recording);
    if (recording) {
        //pause
        rec.pause();
        pauseButton.innerHTML = "Resume";
        recording = false;
    } else {
        //resume
        rec.resume()
        pauseButton.innerHTML = "Pause";

    }

}

function stopRecording() {
    console.log("stopButton clicked");

    //disable the stop button, enable the record too allow for new recordings
    stopButton.disabled = true;
    recordButton.disabled = false;
    pauseButton.disabled = true;

    //reset button just in case the recording is stopped while paused
    pauseButton.innerHTML = "Pause";

    //tell the recorder to stop the recording
    rec.stop();

    //stop microphone access
    // gumStream.getAudioTracks()[0].stop();

    //create the wav blob and pass it on to createDownloadLink
    // rec.exportWAV(createDownloadLink);
    console.log(rec);

    rec.ondataavailable = function (typedArray) {
        console.log('Data received');
        var dataBlob = new Blob([typedArray], { type: 'audio/ogg' });
        createDownloadLink(dataBlob);
        // var fileName = new Date().toISOString() + ".opus";
        // var url = URL.createObjectURL( dataBlob );

        // var audio = document.createElement('audio');
        // audio.controls = true;
        // audio.src = url;

        // var link = document.createElement('a');
        // link.href = url;
        // link.download = fileName;
        // link.innerHTML = link.download;

        // var li = document.createElement('li');
        // li.appendChild(link);
        // li.appendChild(audio);

        // recordingslist.appendChild(li);
    };

}




function createDownloadLink(blob) {

    //name of .wav file to use during upload and download (without extendion)
    var filename = new Date().toISOString();

    //coversion to ogg in the background
    // convertStreams(blob);

    var url = URL.createObjectURL(blob);
    var au = document.createElement('audio');
    var li = document.createElement('div');
    var link = document.createElement('a');
    var breakLine = document.createElement('br');
    var hr = document.createElement('hr');
    var fileName = document.createElement('h6');
    var fileNameHold;
    var progressBar = document.createElement('div');
    var audioPost = document.createElement('div');
    var copyButton = document.createElement('button');
    copyButton.innerHTML = "Copy";
    copyButton.classList.add('copyButton');



    li.classList.add('recordingList');
    audioPost.classList.add('audioPost');



    //add controls to the <audio> element
    au.controls = true;
    au.src = url;

    //save to disk link
    link.href = url;
    link.download = filename + ".ogg"; //download forces the browser to donwload the file using the  filename
    link.innerHTML = "Download";
    link.classList.add("recordingInfo");
    link.style.fontWeight = "bolder";

    // removal of no record status
    document.getElementById("norecords").style.display = "none";

    //add the new audio element to li
    li.appendChild(au);

    li.appendChild(breakLine);

    //add the filename to the li
    fileNameHold = document.createTextNode(filename + ".wav ");
    fileName.appendChild(fileNameHold);
    fileName.classList.add("recordingInfo");
    li.appendChild(fileName);


    //add the save to disk link to li
    li.appendChild(link);


    //upload link
    var upload = document.createElement('a');
    upload.href = "#recordingsList";
    upload.innerHTML = "Upload";
    upload.addEventListener("click", function (event) {
        //   var xhr=new XMLHttpRequest();

        //   xhr.onload=function(e) {
        //       if(this.readyState === 4) {
        //           console.log("Server returned: ",e.target.responseText);
        //       }
        //   };
        //   var fd=new FormData();
        //   fd.append("audio_data",blob, filename);
        //   xhr.open("POST","upload.php",true);
        //   xhr.send(fd);
        var fileNameDir = blogName + "/" + filename;
        var recordFileRef = recordingsRef.child(fileNameDir);
        console.log(recordFileRef.fullPath);
        var uploadTask = recordFileRef.put(blob);
        upload.classList.add('disabled');
        upload.innerHTML = "Uploading...Please wait.";

        uploadTask.on('state_changed', function (snapshot) {
            // Observe state change events such as progress, pause, and resume
            // Get task progress, including the number of bytes uploaded and the total number of bytes to be uploaded

            var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            console.log('Upload is ' + progress + '% done');
            progressDiv.style.width = progress + '%';
            progressDiv.setAttribute("aria-valuenow", progress);


            switch (snapshot.state) {
                case firebase.storage.TaskState.PAUSED: // or 'paused'
                    console.log('Upload is paused');
                    break;
                case firebase.storage.TaskState.RUNNING: // or 'running'
                    console.log('Upload is running');
                    break;
            }
        }, function (error) {
            // Handle unsuccessful uploads
            console.log(error);
            upload.classList.add("show");

        }, function () {
            // Handle successful uploads on complete
            // For instance, get the download URL: https://firebasestorage.googleapis.com/...
            uploadTask.snapshot.ref.getDownloadURL().then(function (downloadURL) {
                var audioPostCode = '<audio class="js-player" controls><source src="' + downloadURL + '" type="audio/wav"></audio>';
                console.log('File available at', downloadURL);
                childDiv.style.display = "none";
                audioPost.appendChild(document.createTextNode(audioPostCode));
                li.appendChild(audioPost);
                copyButton.addEventListener("click", function () {
                    copyStringToClipboard(audioPostCode);
                    copyButton.innerHTML = "Copied!";
                })
                li.appendChild(copyButton);
                li.appendChild(hr);
                upload.classList.add("hide");
            });
        });



    })
    li.appendChild(document.createTextNode(" "))//add a space in between
    upload.classList.add("recordingInfo");
    upload.style.fontWeight = "bolder";

    li.appendChild(upload)//add the upload link to li

    //progress bar setup
    progressBar.innerHTML = '<div class="progress" style="height:5px; margin-top:10px;"><div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>';
    var childDiv = progressBar.getElementsByTagName('div')[0];
    var progressDiv = childDiv.getElementsByTagName('div')[0];

    li.appendChild(progressBar);
    // li.tagName = "recordings";

    //add the li element to the div
    if (noOfRecords < 1) {
        recordingsList.appendChild(li);
    } else {
        var records = document.getElementById("recordingsList");
        records.insertBefore(li, records.firstChild);
    }

    // hr.classList.add("hide");
    noOfRecords++;



}
function copyStringToClipboard(str) {
    // Create new element
    var el = document.createElement('textarea');
    // Set value (string to be copied)
    el.value = str;
    // Set non-editable to avoid focus and move outside of view
    el.setAttribute('readonly', '');
    el.style = { position: 'absolute', left: '-9999px' };
    document.body.appendChild(el);
    // Select text inside element
    el.select();
    // Copy text to clipboard
    document.execCommand('copy');
    // Remove temporary element
    document.body.removeChild(el);
}


//         function processInWebWorker() {
//             var blob = URL.createObjectURL(new Blob(['importScripts("' + workerPath + '");var now = Date.now;function print(text) {postMessage({"type" : "stdout","data" : text});};onmessage = function(event) {var message = event.data;if (message.type === "command") {var Module = {print: print,printErr: print,files: message.files || [],arguments: message.arguments || [],TOTAL_MEMORY: message.TOTAL_MEMORY || false};postMessage({"type" : "start","data" : Module.arguments.join(" ")});postMessage({"type" : "stdout","data" : "Received command: " +Module.arguments.join(" ") +((Module.TOTAL_MEMORY) ? ".  Processing with " + Module.TOTAL_MEMORY + " bits." : "")});var time = now();var result = ffmpeg_run(Module);var totalTime = now() - time;postMessage({"type" : "stdout","data" : "Finished processing (took " + totalTime + "ms)"});postMessage({"type" : "done","data" : result,"time" : totalTime});}};postMessage({"type" : "ready"});'], {
//                 type: 'application/javascript'
//             }));

//             var worker = new Worker(blob);
//             URL.revokeObjectURL(blob);
//             return worker;
//         }

//         var worker;

//         function convertStreams(audioBlob) {
//             var aab;
//             var buffersReady;
//             var workerReady;
//             var posted;

//             var fileReader = new FileReader();
//             fileReader.onload = function() {
//                 aab = this.result;
//                 postMessage();
//             };
//             fileReader.readAsArrayBuffer(audioBlob);

//             if (!worker) {
//                 worker = processInWebWorker();
//             }

//             worker.onmessage = function(event) {
//                 var message = event.data;
//                 if (message.type == "ready") {
//                     console.log('<a href="'+ workerPath +'" download="ffmpeg-asm.js">ffmpeg-asm.js</a> file has been loaded.');

//                     workerReady = true;
//                     if (buffersReady)
//                         postMessage();
//                 } else if (message.type == "stdout") {
//                     console.log(message.data);
//                 } else if (message.type == "start") {
//                     console.log('<a href="'+ workerPath +'" download="ffmpeg-asm.js">ffmpeg-asm.js</a> file received ffmpeg command.');
//                 } else if (message.type == "done") {
//                     console.log(JSON.stringify(message));

//                     var result = message.data[0];
//                     console.log(JSON.stringify(result));

//                     var oggBlob = new File([result.data], 'test.ogg', {
//                         type:' audio/ogg'
//                     });

//                     console.log(JSON.stringify(oggBlob));

//                     // PostBlob(blob);
//                     // oggBlob = blob;
//                 }
//             };
//             var postMessage = function() {
//                 posted = true;

//                 worker.postMessage({
//                     type: 'command',
//                     arguments: '-i audio.wav -c:a vorbis -b:a 4800k -strict experimental output.ogg'.split(' '),
//                     files: [
//                         {
//                             data: new Uint8Array(aab),
//                             name: "audio.wav"
//                         }
//                     ]
//                 });
//             };
//         }

// function uploadToFirebase() {

// }
