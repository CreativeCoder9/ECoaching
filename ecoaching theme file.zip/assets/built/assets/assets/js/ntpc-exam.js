"use strict"; // Start of use strict


var validExam = true;
var focus = setInterval( checkFocus, 200 );






function fullProofExam() {
    alert("Session will expire if you exit the page!");
}

function checkFocus() {
    if ( document.hasFocus() == false ) {
        // alert("javascript works", window.location.reload());
        if (confirm("Session expired!.You have tried to exit the window. This page will now refresh.")) {
            window.location.reload();
        }
        
    }

}


document.addEventListener("mouseleave", fullProofExam);


$(document).ready(function(){
    var timer;
    var isStopped = true;
    var sessionCounter = 110;
    var breakCounter = 2;
    var sec = 60;
    var min = sessionCounter;
    var totalSec = sessionCounter*60;
    
    var width = 0;
    var clicks = 0;
    
    var green = '#7dc194';
    var red = '#ff9999';
    var progressColor = red;
    var clockSessionText = "Session";
    var clockBreakText = "Extra time!";
    
    var $audio = $("audio")[0]; 
    var $clockText = $(".clock-text")
    var $countUpSession = $(".clock-session .arrow-up");
    var $countDownSession = $(".clock-session .arrow-down");
    var $countUpBreak = $(".clock-break .arrow-up");
    var $countDownBreak = $(".clock-break .arrow-down");
    var $sessionClockTime = $(".clock-session .time-text");
    var $breakClockTime = $(".clock-break .time-text");
    var $sessionClock = $(".clock-session .circle-shape");
    var $breakClock = $(".clock-break .circle-shape, .clock")   
    var $timer = $(".clock #timer");
    var countCycle = 0;
    var examTime = (sessionCounter + breakCounter)*60;
    // console.log(examTime);
  
    
       $("document").ready(function (evt) {
         clicks++;
         if(clicks > 1) {
           isStopped = false;
         }

         pomodoro();   
       });
   
  
    
     // end of click functions
    
    function countDown(counter, clockName){
       if(counter === 1){
         counter = 1;
         if($clockText.text() === clockSessionText && clockName === clockSessionText || 
            $clockText.text() === clockBreakText && clockName === clockBreakText ){
          sec = 60;
         }
         return;
       }
       if(counter>1){
         counter--;
         
         if(sceaduleNextTime(counter, clockName)){
           return counter;
         }    
         min = counter-1;
        //  resetTime(counter, clockName);
         return counter;
         }
      }//end of countDowen func
  
      function countUp(counter, clockName){
         counter++;
        console.log(counter + "a")
        sceaduleNextTime(counter, clockName);
          if(sceaduleNextTime(counter, clockName)){
           return counter;
         }    
         min = counter+1;
        //  resetTime(counter, clockName);
        console.log(counter + "b")
         return counter;
     }//end of countUp func
    
    function sceaduleNextTime(counter, clockName){
      if($clockText.text() === clockSessionText && clockName === clockBreakText){
            breakCounter = counter;
        console.log(counter + "st")
            return counter;
                 }//possibility to change next break length while session counts down
      if($clockText.text() === clockBreakText && clockName === clockSessionText){
            sessionCounter = counter;
        console.log(counter + "ts")
            return counter;
                 }//possibility to change next session length while break counts down
        
      return false;
    }//end of sceaduleNextTime func
  
  
  // function resetTime(counter, clockName){
  //      if(clockName === clockSessionText){
  //        sessionCounter = counter;
  //      }
  //      if(clockName === clockBreakText){
  //        breakCounter = counter;
  //      }
  //      if($clockText.text() === clockBreakText && clockName === clockBreakText){ //possibility to reset break on new value, while braek counts
  //        totalSec = breakCounter*60;
  //        min = breakCounter;
  //        sec = 60;
  //        width = 0;
  //      }
  //      if($clockText.text() === clockSessionText && clockName === clockSessionText){ //possibility to reset session on new value, while session counts
  //        totalSec = sessionCounter*60;
  //        min = sessionCounter;
  //        sec = 60;
  //        width = 0;
  //      }   
  // } //end of setMinutes function
    
  
  
    //Setting timer minutes and progress bar for changes of session and break
    function changeOnBreak(){
      // console.log(countCycle);
      if(countCycle == examTime) {
        isStopped = true;
        $clockText.text("Time UP!");
        console.log($clockText.text());
        $audio.play();
        $audio.play();
        $audio.play();
        throw("SYSTEM IS EXITING >>>>> BYE BYE!!!")
      } else {
        if($clockText.text() === clockSessionText && sec === 60){
          sec = 59;
          min = sessionCounter-1;
          width = 0;
          $sessionClock.addClass("activated-cs");
          $audio.play();
          
           }
        if($clockText.text() === clockBreakText && sec === 60){
          sec = 59;
          min = breakCounter-1;
          width = 0;
          $breakClock.addClass("activated-cb");
          
           }
        if(min === 0 && sec < 0 && $clockText.text() === clockBreakText){
          $breakClock.removeClass("activated-cb");
          $sessionClock.addClass("activated-cs");
          $clockText.text(clockSessionText);
          min = sessionCounter;
          totalSec = sessionCounter*60;
          progressColor = red;
          width = 0;
          $audio.play();
        }
        if(min === 0 && sec < 0 && $clockText.text() === clockSessionText){
          $sessionClock.removeClass("activated-cs");
          $breakClock.addClass("activated-cb");
          $clockText.text(clockBreakText);
          min = breakCounter;
          totalSec = breakCounter*60;
          progressColor = green;
          width = 0;
          $audio.play();
        }
      }
      countCycle++;
      if(countCycle > sessionCounter*60){
        $audio.play();
        console.log("WORKING");
      } 
               
    }
    
   //Setting progress bar
      function progressBar(){
        
          var totalWidth = 100;
          var incrementWidth = totalWidth/totalSec;
          width += incrementWidth;
          /*elem.style.width = width + '%'; */
          $("#timer-progress").css({"width": width + '%', "background-color": progressColor}); 
        
      } //end of progressBar func
    
  
   //Strat timer function
      function startTimer(){  
   
        changeOnBreak();
        progressBar();
         
       if(sec < 10 && sec >= 0){   
         return $timer.html(min + ":0" + sec--);
        } //ad '0' before sec 1-9
        
        if(min !== 0 && sec < 0){
          sec = 59;  
          min = min-1 ; 
        } //countdown min for one, and reset sec when sec countdowned to 0
        
        $timer.html(min + ":" + sec--);
  
     } //end of startTimer func
    
    //Run pomodoro clock on every sec, or stop pomodoro
    function pomodoro(){
      
      
       if(!isStopped){ 
           isStopped = true;
           clicks = 0;
           return clearTimeout(timer)
           /* return clearInterval(timer); //Pause timer function on click clock timer again */
         }
        $(".timer-progress-bar, .timer-progress").css("display", "block").addClass('animated zoomIn');
         
        timer = setTimeout(function go() {
          startTimer();    
          isStopped = false;
          clicks = 0;
        timer = setTimeout(go, 1000);
        }, 1000);
        
         /*timer = setInterval(startTime, 200); isStopped = false;*/ // Start count on clock timer click
    } // end of pomodoro func
      
  }); //end of doc.ready
