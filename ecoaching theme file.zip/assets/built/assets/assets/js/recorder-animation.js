let mic, fft;
function setup() {
  let width= screen.width/2;
  var canvas = createCanvas(width, 100);
  canvas.parent('sketch-div');
  noFill();

  mic = new p5.AudioIn();
  mic.start();
  fft = new p5.FFT();
  fft.setInput(mic);
}

function draw() {
  background(255);

  let spectrum = fft.analyze();

  beginShape();
  for (i = 0; i < spectrum.length; i++) {
    vertex(i, map(spectrum[i]*2, 0, 255, height/2, 0));
  }
  endShape();
}
